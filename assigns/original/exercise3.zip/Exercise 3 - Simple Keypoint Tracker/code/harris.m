function scores = harris(img, patch_size, kappa)
