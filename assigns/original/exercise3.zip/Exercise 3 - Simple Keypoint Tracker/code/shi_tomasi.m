function scores = shi_tomasi(img, patch_size)
