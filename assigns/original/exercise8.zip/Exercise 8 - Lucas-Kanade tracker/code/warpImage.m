function I = warpImage(I_R, W)
