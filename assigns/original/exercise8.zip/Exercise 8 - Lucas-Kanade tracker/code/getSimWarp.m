function W = getSimWarp(dx, dy, alpha_deg, lambda)
% alpha given in degrees, as indicated
